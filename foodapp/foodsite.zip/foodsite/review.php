<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Food Website</title>
        <link rel="stylesheet" href ="styleR.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    </head>
<body>
    <!-- review -->
   <div class="review" id="review">
    <h1>Customer<span>Review</span></h1>
    <div class="review_box">
      <div class="review_card">

        <div class="review_profile">
          <img src="girl.jpg">
        </div>
        <div class="review_text">
          <h2 class="name"> John Deo</h2>
             <div class="review_icon">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star-half-stroke"></i>               
             </div>

             <div class="review_social"></div>
             <i class="fa-brands fa-facebook-f"></i>
             <i class="fa-brands fa-instagram"></i>
             <i class="fa-brands fa-twitter"></i>
             <i class="fa-brands fa-linkedin-in"></i>
        </div>
        <p>"I'm a passionate foodie, and this place blew me away! The flavors were exquisite, and the presentation was top-notch. I tried their signature dish, and every bite was a burst of delight. The ambiance was cozy, adding to the overall experience. I can't wait to return and explore more from their menu!"</p>
      </div>
      <div class="review_card">

        <div class="review_profile">
          <img src="girl.2.jpg">
        </div>
        <div class="review_text">
          <h2 class="name"> John Deo</h2>
             <div class="review_icon">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star-half-stroke"></i>               
             </div>

             <div class="review_social"></div>
             <i class="fa-brands fa-facebook-f"></i>
             <i class="fa-brands fa-instagram"></i>
             <i class="fa-brands fa-twitter"></i>
             <i class="fa-brands fa-linkedin-in"></i>
        </div>
        <p>"As someone focused on healthy eating, I found this place quite accommodating. The menu offered a good variety of nutritious options. The salad I ordered was fresh and flavorful, incorporating organic ingredients. However, the portion sizes were a bit small for the price. Overall, a good spot for those seeking healthier choices."</p>
      </div> <div class="review_card">

        <div class="review_profile">
          <img src="girl1.jpg">
        </div>
        <div class="review_text">
          <h2 class="name"> John Deo</h2>
             <div class="review_icon">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star-half-stroke"></i>               
             </div>

             <div class="review_social"></div>
             <i class="fa-brands fa-facebook-f"></i>
             <i class="fa-brands fa-instagram"></i>
             <i class="fa-brands fa-twitter"></i>
             <i class="fa-brands fa-linkedin-in"></i>
        </div>
        <p>"I love trying new cuisines, and this place intrigued me with its fusion concept. While the idea was innovative, the execution fell short. The flavors seemed confused and didn't quite harmonize. However, the staff was friendly, and the concept itself has potential. Hoping they refine their dishes for a more satisfying experience."</p>
      </div> <div class="review_card">

        <div class="review_profile">
          <img src="boy 2.jpg">
        </div>
        <div class="review_text">
          <h2 class="name"> John Deo</h2>
             <div class="review_icon">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star-half-stroke"></i>               
             </div>

             <div class="review_social"></div>
             <i class="fa-brands fa-facebook-f"></i>
             <i class="fa-brands fa-instagram"></i>
             <i class="fa-brands fa-twitter"></i>
             <i class="fa-brands fa-linkedin-in"></i>
        </div>
        <p>"I stumbled upon this spot and was pleasantly surprised. The menu had familiar options, and the food was comforting and tasty. I ordered a classic burger, and it hit the spot. The prices were reasonable, and the service was quick. A decent place for a relaxed meal." </p>
      </div>
    </div>
   </div>
</body>
</html>
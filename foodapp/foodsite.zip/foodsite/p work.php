<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="chrome">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href ="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

</head>

<body bgcolor="powderblue">

<section id="Home">
    <nav>
        <div class="logo">  
            <img src="food logo.jpeg">

        </div>
        <ul>
            <li><a href ="#Home">Home</li>
            <li><a href ="#About">About</li>
            <li><a href ="#Menu">Menu</li>
            <li><a href ="#Gallary">Gallary</li>
            <li><a href ="#Review">Review</li>
            <li><a href ="#Order">Order</li>
        </ul>
        <div class="icon">
<i class="fa-solid fa-magnifying-glass"></i>
<i class="fa-solid fa-heart"></i>
<i class="fa-solid fa-cart-shopping"></i>


        </div>
   <div class="main">

    <div class="men_text">
        <h6>Get Fresh<span>Food<br>in a Easy Way</span></h6>
    </div>

    
   </div>
    </nav>
    <div class="main_image">
        <img src="burger.jpg" height="800px" width="100%">
        <div class="main_btn">
            <a href="#">Order Now</a>
            <i class="fa-solid fa-angle-right"></i>
        </div>
    </div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci neque quis quia tempore voluptatibus dolor placeat id odio? Pariatur laborum voluptatem ipsa saepe corporis temporibus incidunt, expedita eum maiores ad.
    Pariatur, in ipsum expedita minus molestias quo perferendis magnam libero. Consequuntur, magni. Nulla, quis exercitationem cum a, nobis optio expedita iure omnis quas aperiam, esse illo explicabo sunt natus architecto!</p>
    <div class="main_btn">
        <a href="#">Order Now</a>
        <i class="fa-solid fa-angle-right"></i>
    </div>
</section>
 <div class="about" id="About"> </div>
    <div class="about_main"> </div>
        <div class="image">
            <img src="pasta.jpg"  height="700px" width="100%">
        </div>  
        
        <div class="About_text">
            <h4><span>About</span>Us</h4>
            <h3>Why choose us?</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam eius sapiente similique voluptatum reiciendis impedit, odit cum obcaecati incidunt sint. Beatae ex veritatis reprehenderit iusto earum ipsum, asperiores rerum repellat.
            Cum obcaecati numquam ipsam repellendus porro, sapiente laborum veritatis dignissimos adipisci quo commodi? Architecto vero ex magni. Adipisci fuga ex eum doloribus qui labore, ut, est, sunt maxime reprehenderit eaque?
            Itaque vero iure repudiandae a at maiores voluptatum vitae, ratione incidunt assumenda quidem consequatur eius quod error nemo quos amet earum quibusdam voluptates enim consequuntur! Fugiat sapiente ipsum recusandae cumque.
            Odit eveniet error porro distinctio quasi iure itaque, sed tempore rerum est officia culpa accusantium dicta aliquid veritatis eos obcaecati neque exercitationem suscipit ipsum sapiente pariatur ad. Est, quis minima!</p>
        </div>
        
    


    
</body>
</html>
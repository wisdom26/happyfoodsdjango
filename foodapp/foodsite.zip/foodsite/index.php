<?php include'header.php';?>   
    <div class="content">
        <h3>Welcome to Happy Food</h3>
        <h1>Rich Healthy and Natural Food</h1>
        <p>Rich Cusinie is a restaurant located in india. We have some amazing recipes and the most talented chefs in the country </p>
    </div>
    <div class="search">
        <input type="text" placeholder="Search Food">

    </div>
      <div class="submit">
        <a href="#"> Submit</a>
      </div>
</body>
</html>
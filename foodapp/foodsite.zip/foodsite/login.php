<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <link rel="stylesheet" href="styleL.css">
  
</head>
<body>
    <script src="script.js"></script>
  <div class="login-container">
    <form id="login-form">
      <h2>Login</h2>
      <div class="input-group">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
      </div>
      <div class="input-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button type="submit">Login</button>
      <p id="error-message"></p>
    </form>
  </div>
  
  <script src="script.js"></script>
</body>
</html>
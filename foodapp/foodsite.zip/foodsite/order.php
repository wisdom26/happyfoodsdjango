<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Responsive Contact Us Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href ="styleO.css">

</head>

<body>
    <!-- order -->
   <div class="order" id="order">
    <h1><span>Order</span>Now</h1>

    <div class="order_main">
         <div class="order_image">
             
         </div>
         <form action="#">
         <div class="input">
          <p>Name</p>
          <input type="name" placeholder="you name">
         </div>
         <div class="input">
          <p>Email</p>
          <input type="email" placeholder="you email">
         </div>
         <div class="input">
          <p>Number</p>
          <input placeholder="you number">
         </div>
         <div class="input">
          <p>How much</p>
          <input type="text" placeholder="you name">
         </div>
         <div class="input">
          <p>Your Order</p>
          <input  placeholder="food name">
         </div>
          <div class="input">
          <p>Address</p>
          <input type="text" placeholder="you address">
         </div>
         <a href="ordersuc.html" class="order_btn">Order</a>
        </form>
         </div>
    </div>
   </div>
</body>
</html>
!